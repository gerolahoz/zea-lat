---
name: cazar
description: Busca ofertas ganadoras de productos digitales en la Biblioteca de Anuncios de Meta (en cualquier país) y devuelve una shortlist de anunciantes validados, con su arsenal de anuncios, su landing y un veredicto. Usar cuando el usuario diga "cazar", "buscar winners", "buscar ofertas", "analizar nicho" o "espiar anuncios".
---

# /cazar — Encontrar ofertas ganadoras en la Biblioteca de Anuncios

El argumento es el **nicho, la keyword o el mercado** a investigar (ej.: `/cazar crochet en Italia`, `/cazar recetas keto`). Si no se pasa nada, barrer los mercados y keywords de la tabla del Paso 1.

La lógica de fondo: **nadie deja 15, 30 o 100 anuncios prendidos durante semanas si no vende.** La Biblioteca de Anuncios es pública y muestra qué está funcionando. Esta skill encuentra esas ofertas, descarta las que no se pueden modelar y te deja una lista corta para decidir.

## Herramienta

- Se trabaja **con el navegador de Claude** sobre `https://www.facebook.com/ads/library/`. No hace falta login, API ni conector.
- Es **solo lectura**: no toca ninguna cuenta publicitaria, así que no hay riesgo de bloqueo.
- **Rate limit:** Meta limita cuando hay muchas búsquedas en paralelo. Máximo 2-3 pestañas o agentes a la vez. El modo de falla es traicionero: en vez de un error, muestra "No ads match your search criteria". Por eso, antes de cada tanda se corre un **canario**: buscar algo que seguro existe (`crochet` en US o `receitas` en BR). Si el canario da cero, frenar y esperar. Bajo rate limit, los resultados **positivos** valen (si contaste 66 videos, la página cargó); los **ceros** no.

### URLs que se usan

- **Búsqueda por keyword en un país:**
  `https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=<ISO2>&q=<keyword>&search_type=keyword_unordered&media_type=all`
- **Arsenal completo de un anunciante (ordenado por impresiones):**
  `https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=ALL&is_targeted_country=false&media_type=all&search_type=page&sort_data[mode]=total_impressions&sort_data[direction]=desc&view_all_page_id=<PAGE_ID>`
- **Mismo arsenal, solo videos:** cambiar `media_type=all` por `media_type=video`.

### Qué leer de cada página

- En el HTML vienen apareados `"page_id":"..."` y `"page_name":"..."`, en orden.
- La **landing real** se obtiene decodificando el parámetro `?u=` de los links `l.facebook.com` de cada anuncio.
- En el arsenal, el contador `~N results` es la cantidad de anuncios activos.
- Los títulos del arsenal (`"title":"..."`) sirven para contar cuántos productos distintos vende.
- Si algo del HTML no carga (contenido dinámico), hacer scroll y esperar 2-3 s antes de leer.

## Paso 1 — Barrido por mercado y keyword

Para cada mercado, buscar cada keyword y anotar por anunciante: `page_id`, nombre, moneda, cuántas veces aparece y 2-3 hooks de muestra. Si un mismo `page_id` aparece en varios mercados, sumarlo.

| Mercado | ISO | Keywords (idioma local) |
|---|---|---|
| Estados Unidos | US | printable, PDF guide, digital pattern, template pack, cheat sheet, step-by-step guide, workbook, bundle, blueprint, mega pack |
| Reino Unido | GB | printable, PDF guide, digital pattern, template pack, cheat sheet, step-by-step guide, workbook, bundle, blueprint |
| Italia | IT | corso, guida completa, PDF, metodo, kit digitale, ebook, formazione, pack, protocollo, sistema |
| Polonia | PL | kurs, przewodnik, PDF, zestaw, ebook, metoda, pack, poradnik, plan |
| Rumania | RO | ghid complet, curs, kit, PDF, ebook, metoda, pachet, plan, protocol |
| Hungría | HU | tanfolyam, útmutató, PDF, csomag, e-könyv, módszer, terv, recept, lépésről lépésre útmutató, minta |
| Francia | FR | cours, guide complet, PDF, méthode, kit, ebook, pack, plan, protocole, formation |
| Brasil | BR | método, segredo, desafio, renda extra, passo a passo, PDF completo, curso online, kit, pack, receita |
| Argentina | AR | pack, curso, método, mini curso, guía, PDF, kit, sistema, plantillas, plan |

Si falta volumen, sumar mercados (MX, CO, PE, CL, ES, EC, PT, DE) y más keywords por 4 ejes:
- **Formato:** ebook, guía, plantilla, kit, método, protocolo, pack, workbook.
- **Disparadores de compra impulsiva:** paso a paso, desafío, secreto, renta extra, en X días.
- **Huellas técnicas:** nombres de plataformas de pago o de entrega que aparezcan en el texto del anuncio.
- **Keywords del nicho** traducidas al idioma de cada mercado.

**Descartar sin enumerar:**
- Monedas de mercados que no te interesan (por ejemplo INR, PHP, VND, PKR).
- Páginas con nombres genéricos de revendedores masivos ("Digital", "Digitals", "Products", "Solutions", "Market", "Store" solos). Suelen ser cloakers.

## Paso 2 — Contar el arsenal real

Pasan a este paso los anunciantes con **5 o más apariciones** en el barrido. Para cada uno, abrir su arsenal completo (URL de arriba) y anotar:
- Cantidad de anuncios activos.
- Fecha del anuncio activo más viejo.
- Cuántos anuncios en video tiene (misma URL con `media_type=video`).
- Landing real.

## Paso 3 — Filtros duros (eliminatorios)

Un candidato pasa solo si cumple **todo** esto:

- **15 o más anuncios activos** sobre la misma oferta. (Con un corte de 50 se cuelan catálogos, que es justo lo que hay que descartar).
- **El anuncio activo más viejo tiene 3 días o más.** Lo que arrancó hoy es alguien testeando; lo que lleva días ya vende.
- **Al menos 1 anuncio en video** (filtro E, abajo).
- El copy menciona un formato digital (PDF, guía, curso, método, pack, kit, bundle, printable, workbook, plantilla, protocolo, ebook).

Y **no** cae en ninguno de estos:

- **A · Marca personal.** No se juzga por el nombre de la página. Descalifica que el anuncio y la landing se apoyen en la autoridad de una persona: la misma cara en todos los creativos, copy con sus números ("+38.000 alumnas"), un título en el nombre (Profesor, Dr., Coach, Chef), una landing que abre con bio y credenciales. Una oferta con nombre de persona pero centrada en el producto, pasa.
- **B · Multiproducto.** Sirve **una sola oferta atacada desde muchos ángulos**, no un catálogo. Test: agrupar los títulos del arsenal y contar cuántos **productos** distintos nombran, no cuántos títulos distintos hay. Se acepta una oferta principal con order bumps o upsells después del checkout, siempre que todos los anuncios empujen la misma oferta de entrada.
- **C · CTA a WhatsApp.** `wa.me`, `api.whatsapp.com`, o copy tipo "escribinos por WhatsApp" / "fale com". No es un embudo con checkout replicable. **Se revisa sobre todo el HTML del arsenal** (`/wa\.me|api\.whatsapp/i`): leer el texto de los primeros anuncios no alcanza, porque en LATAM y Brasil el WhatsApp casi nunca está en el primero.
- **D · Lead magnet gratis.** Si el CTA va a un webinar, ebook o clase gratis en vez de a un checkout, fuera.
- **E · Sin video.** El arsenal tiene que tener al menos un anuncio en video.
- **G · Retail o catálogo.** Editoriales, librerías o tiendas con muchos productos. Que el entregable llegue impreso no descalifica; que la operación sea una tienda, sí.

El formato del producto (pack descargable, curso con módulos, app, híbrido) **no descalifica**: se anota como dato en la ficha.

## Paso 4 — Verificación visual (obligatoria)

Los filtros A, B y C no se resuelven leyendo datos: hay que mirar el arsenal. Para cada finalista:
1. ¿Aparece la misma persona de forma recurrente en los creativos? → A.
2. ¿Cuántos productos distintos vende? 3 o más → B.
3. Buscar "whatsapp" en toda la página del arsenal. Un solo resultado → C.
4. ¿El CTA va a un checkout o a algo gratis? → D.
5. Contador con `media_type=video` en 0 → E.
6. Anotar la landing real.

**Si queda una duda que decide si pasa o no, el candidato va a "Reserva"**, no a la lista limpia.

**Una oferta = un candidato.** Si el mismo producto corre localizado en varios mercados (mismo producto, mismo checkout, mismo vendedor), va una sola fila y los otros mercados se anotan dentro de la ficha.

## Paso 5 — Score de 4 señales (para rankear)

1 punto por cada una:
1. **Longevidad:** el anuncio más viejo lleva 45 días o más. Nadie banca 2-3 meses de gasto perdedor.
2. **Volumen:** 50 o más anuncios de un solo jugador sobre la misma oferta.
3. **Duplicación:** el mismo creativo o título repetido 10 o más veces. Ese ya ganó el test interno del anunciante: es el primer ángulo a modelar.
4. **Arbitraje:** buscar la misma keyword traducida en 2-3 mercados destino. Si en alguno hay 0-1 jugadores fuertes, hay hueco.

**4/4 = WHALE / candidata A** (copiala) · **3/4 = candidata B** · **≤2 = observar**.

Otras señales que suman confianza:
- Todos los anuncios apuntan a la **misma landing** (si apuntan a varias, todavía está testeando).
- La misma oferta corre en 5-10 páginas distintas: se esconde de los que copian, y convierte.
- Sin anuncios de "seguime": los perfiles que solo juntan seguidores no venden.

## Paso 6 — Veredicto de competencia por nicho

Contar cuántos anunciantes distintos atacan la misma promesa:
- **ENTRAR:** 2-6 anunciantes con gasto sostenido y ninguno domina. Demanda validada y hay espacio.
- **SUBNICHO:** 7 o más con creativos muy parecidos. Validado pero saturado: proponer 3 subnichos concretos (mismo dolor, avatar más específico).
- **DESCARTAR:** 0-1 anunciantes, o anuncios que mueren a los pocos días.
- **WHALE DOMINANTE:** un jugador domina. No competirle de frente en su mercado: modelar su oferta y lanzarla traducida en otro mercado con hueco.

### Arbitraje entre mercados

El juego más rentable suele ser **modelar desde un mercado fuente saturado y lanzar en un destino vacío**. Brasil es la cuna de muchas olas de productos baratos (mercado fuente). Orden de prioridad de destino: 1) inglés, 2) Europa (Italia, Francia, Alemania, Polonia, Rumania), 3) LATAM, 4) Brasil. Si en el destino ya aparecen anunciantes con anuncios de pocos días, la ventana se está cerrando.

## Paso 7 — Entregable

**Meta: 15 candidatos que cumplan todos los filtros.** La tasa de supervivencia suele rondar el 20-25%, así que para llegar a 15 hay que evaluar unos 60-65 candidatos. Si no alcanza, sumar mercados, keywords y nichos hasta llegar. Si la sesión se corta, guardar el avance en un archivo y retomar.

Para cada candidato:

```
### N. [ ] <Anunciante> · <nicho> · <score>/4 · <mercado principal>
- Arsenal: N anuncios activos · el más viejo: D días · videos: V
- Duplicación: "<hook o título más repetido>" × K
- Ángulo: <el dolor que ataca = lo que está validado>
- Producto y precio: <si se ve>
- Landing: <url real>
- Arsenal ordenado por impresiones: <URL de arsenal>
- Otros mercados donde corre: <si aplica>
- Veredicto: WHALE / A / B / observar · <por qué>
```

Cerrar con el veredicto del nicho (ENTRAR / SUBNICHO / DESCARTAR / WHALE) y, si aplica, el par **mercado fuente → destino**.

Siempre linkear el **arsenal completo ordenado por impresiones**, nunca un anuncio suelto.

## Aprendizaje (Sí / No)

Pedirle al usuario que marque cada candidato con **Sí** (me interesa) o **No** (+ un motivo corto). Guardar las respuestas en `scouting/criterio-aprendido.md`:
- Ranking de nichos, mercados y formatos por tasa de "Sí".
- Patrones de rechazo (y a qué filtro corresponden).
- Blocklist temporal: anunciantes presentados 3 o más veces sin un "Sí" quedan bloqueados 7 días.

En cada búsqueda nueva, leer ese archivo primero y usarlo para ordenar: +1 si el nicho está en el top 3 de aceptación, +1 si el mercado está en el top 3, +1 si el formato coincide con lo que suele aceptar, −2 si coincide con un patrón rechazado. Un "Sí" sobre algo que un filtro había descartado indica que ese filtro está mal calibrado: anotarlo.

**Marcar "Sí" no arranca la producción.** Solo ajusta el criterio. Para producir una oferta, el usuario la elige a mano y corre `/modelar`.

## Reglas

1. **No inventar datos.** Si no hay landing detectable, poner "no detectada". Si no se contó el arsenal, no se incluye.
2. **Solo lectura.** Nunca crear, editar ni pausar nada en ninguna cuenta publicitaria.
3. **Fechas absolutas** (2026-09-24, no "ayer").
4. **Reparto justo:** que un solo mercado no ocupe más de 6 de los 15 lugares.
5. **Una oferta ganadora valida la OFERTA**, no te salva de un test mal hecho: una landing rota, un píxel ciego o una campaña mal armada queman igual.
