---
name: modelar
description: Clona una oferta ganadora de producto digital (oferta + landing + tienda + anuncios + entregables) a un mercado nuevo, a partir de su link de la Biblioteca de Anuncios y su landing real. Usar con "/modelar", "quiero modelar esta oferta" o "modelá esto para [mercado]". No reinventa la oferta: la adapta.
---

# /modelar — Llevar una oferta ganadora a un mercado nuevo

La idea: si una oferta ya vende en un mercado (muchos anuncios activos durante semanas), la llevás a otro mercado donde todavía no está o está tranquila. **No se reinventa: se adapta** (idioma, cultura, moneda, ejemplos).

Orden fijo, con dos pausas obligatorias para que apruebes antes de gastar:

1. Oferta + landing + mockups + tienda → **🛑 Pausa 1** (aprobás la tienda)
2. 10 anuncios → **🛑 Pausa 2** (aprobás los anuncios)
3. Lanzamiento (lo disparás vos)
4. Entregables (el producto en sí), **mientras la campaña ya corre**

¿Por qué los entregables van al final? Porque son lo que más tarda. Si los hacés antes, tardás días en lanzar. Si la oferta no vende en el test, te ahorraste el trabajo.

## Fase 0 · Dos preguntas, siempre las mismas y en este orden

1. **"¿En qué mercado vamos a lanzar la oferta?"** (ej.: Italia, EE. UU./anglo, LATAM, Argentina, Rumania, Francia, Polonia). Confirmar idioma, trato (tú / vos / usted) y moneda.
2. **"Dame los dos links de referencia":**
   - El **arsenal completo** del anunciante en la Biblioteca de Anuncios (`search_type=page` + `view_all_page_id`, ordenado por impresiones), no un anuncio suelto.
   - La **landing real**. Si tiene cloaker (el link muestra otra página), pedir el archivo HTML guardado desde el navegador.

No avanzar sin los dos.

## Fase 1 · Extraer la oferta y la landing, tal cual

- Recorrer la landing **sección por sección**, en orden, sin reordenar ni reescribir: hero, dolores, qué incluye, bonos, garantía, testimonios, FAQ, precio, CTA.
- Levantar la **oferta completa**: producto principal + cada bono, con su precio individual si está a la vista, precio tachado y garantía.
- Del arsenal: listar todos los anuncios, rankeados por señal de ganador (más duplicados, más tiempo activos, más impresiones). Todavía no se descargan.
- **Si la landing es una app moderna** (React, Lovable, Next: `curl` trae una página casi vacía), extraer la estructura con el navegador: hacer scroll a cada sección, esperar a que cargue y anotar qué columna tiene imagen y cuál texto. No alternan con un patrón fijo.
- **Colores:** sacarlos del HTML real (`curl <url> | grep -oE '#[0-9a-fA-F]{6}'`). Nunca "a ojo".

## Fase 2 · Clonar la oferta (sin inventar)

- Mismo producto principal, mismos bonos, mismos nombres (traducidos), mismo precio de referencia convertido a la moneda del mercado. **Cero bonos nuevos.**
- Si el checkout original tiene **dos ofertas a la vez** (ej. "básico" y "premium"), colapsar a **una sola**. Si no es obvio qué queda como bono, preguntar.
- Si el producto original es **físico**, avisar antes de seguir: este método es para productos digitales.
- Todo lo que sea una suposición se marca `(suposición, no confirmado)`.

## Fase 3 · Clonar la landing

- **Misma estructura** que el original, sección por sección. Traducir **adaptando**, no literal: si una referencia cultural no tiene sentido en el mercado nuevo, se cambia por una equivalente.
- **Un solo botón va directo al checkout:** el de la sección de precio (`id="offer"`). **Todos los demás** (hero, barra fija, secciones intermedias) llevan a `#offer` con scroll. Si todos van al checkout, se inflan los "checkouts iniciados" pero baja la compra real.
- **Imágenes con personas:** fotos realistas, nunca ilustraciones.
- **Precio grande arriba** en la sección de oferta. Bonos en tarjetas.
- **Perfecta en celular** (la mayoría compra desde el teléfono): revisar a 375 px de ancho.
- Nunca linkear al dominio original.

## Fase 4 · Imágenes con texto

Mockups, certificados o sellos que tengan texto en el idioma original se **regeneran con IA a partir de la imagen original** (image-to-image, ej. GPT Image), nunca desde cero: así se mantiene el diseño y solo cambia el idioma. Resolución 1K alcanza.

## Fase 5 · Un solo título

Fijar **un único nombre** para la oferta, ya traducido. El mismo en landing, mockups, checkout y entregables. Tres nombres distintos confunden al comprador y bajan la conversión.

## Fase 6 · Mockups de checkout

Dos imágenes (IA, 1K): una **hero** (el producto con los bonos alrededor) y una **caja abriéndose**. Fondo blanco tipo packshot. Los entregables todavía no se hacen.

## Fase 7 · Crear la tienda (queda lista para vender)

Plataforma: la que uses (Impultienda, Hotmart, Shopify, etc.). Checklist genérico:

1. Tienda nueva con el **idioma del mercado** y el título de la Fase 5.
2. **Pegar tu propio HTML** de la landing (no dejar que la plataforma genere el texto).
3. **Pagos:** moneda del mercado. Conectar el procesador (ej. Stripe) y **activar los métodos de pago locales** (Pix, OXXO, iDEAL, Klarna, etc., según el país): sube bastante la conversión.
4. **Una sola oferta en el checkout:** el producto principal representa **toda la oferta** (producto + bonos juntos). Título estilo mockup (ej. "Nombre · 120+ plantillas + 5 bonos"). Nada de bonos como productos separados.
5. **Link de entrega:** dejá desde ahora una URL fija (una página de "en preparación"). Cuando tengas los entregables, cambiás el contenido de esa página, nunca la URL, así no hay que tocar el checkout.
6. **Diseño del checkout que uso:**
   - Arriba: cuenta regresiva de 10 minutos + la imagen hero del mockup.
   - Abajo: "cupos restantes".
   - Botón con un texto de acción claro ("QUIERO ACCESO AHORA").
   - Garantía visible (7 días).
   - Datos del comprador: **solo email y teléfono**. Cuantos menos campos, más ventas.
   - Barra de compradores recientes debajo del botón.
7. **Dominio propio** (subdominio) conectado y con SSL activo.
8. **Probar todo:** que los botones hagan scroll a la oferta, que haya un solo precio y que el checkout muestre lo configurado.

## Fase 8 · 🛑 PAUSA 1 — Aprobás la tienda

Entregar el link de la tienda y la landing, y esperar tu OK. No se hacen anuncios hasta que digas "dale".

## Fase 9 · Los 10 anuncios

1. Del arsenal (Fase 1), rankear por señal de ganador y **deduplicar por guion**: el mismo guion subido con otro video cuenta como un solo concepto.
2. Tomar hasta **10 conceptos reales**. Si el arsenal tiene menos, **completar hasta 10 inventando** variaciones sobre esos conceptos y los dolores del comprador. Marcar cada uno como `[replicado]` o `[inventado]`.
3. **Replicados:** analizar cada uno (skill `/watch`) y producirlo como réplica (video original limpio + voz nueva + subtítulos + música). **Inventados:** guion nuevo sobre B-roll o avatar con IA.
4. Escribir el copy de cada anuncio (texto principal, título, descripción, CTA).
5. **Previsualización:** una página HTML con los 10 videos en grilla para verlos juntos. Nunca describirlos en texto.

(El detalle de producción de anuncios con IA está en el kit del video 2).

## Fase 10 · 🛑 PAUSA 2 — Aprobás los anuncios

Revisás los 10 en la previsualización. **Esto todavía no lanza nada.** Vos elegís la cuenta publicitaria y el píxel, y conectás el tracking (ej. Utmify) en la tienda.

## Fase 11 · Lanzamiento (solo cuando lo pedís)

Estructura **CBO madre** (ver `sops/cbo-madre.md`): 1 campaña CBO · objetivo Ventas · 1 conjunto con target al país · los anuncios adentro · presupuesto = 3 veces el ticket · programada para las 00:30 del día siguiente. Se sube desde el Administrador de Anuncios o con una herramienta de carga masiva.

## Fase 12 · Entregables (con la campaña corriendo)

Producir el producto real (PDFs, ebooks, plantillas) con el **mismo título**, fiel a la oferta original (mismos bonos, misma estructura). Subirlos y reemplazar el contenido de la página de entrega de la Fase 7.

## Reglas

1. **No inventar nada de la oferta ni de la landing.** La única excepción son los anuncios de relleno de la Fase 9.
2. **Las dos preguntas de la Fase 0, siempre.**
3. **Checkout con dos ofertas → una sola.**
4. **Un solo título** en todo.
5. **Imágenes con texto: image-to-image sobre la original.**
6. **Las dos pausas no se saltean nunca**, ni con apuro.
7. **Un solo botón al checkout;** el resto, scroll a la oferta.
8. **Métodos de pago locales siempre activados.**
9. **El lanzamiento nunca es automático:** lo das vos, con cuenta y píxel elegidos.
10. **Los entregables van al final.**
11. Antes de clonar textos o imágenes de un tercero, verificar que tenés derecho a usarlos, o reemplazarlos por material propio.
