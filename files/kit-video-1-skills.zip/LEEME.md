# Kit video 1 · Encontrar, modelar y lanzar ofertas de productos digitales

Este kit es el sistema exacto que muestro en el video, convertido en archivos que podés instalar en Claude Code. Incluye:

| Archivo | Qué es |
|---|---|
| `CLAUDE.md` | Las instrucciones de tu "segundo cerebro": cómo trabaja Claude en tu proyecto y cómo aprende de tus correcciones |
| `skills/cazar/SKILL.md` | La skill para encontrar ofertas ganadoras en la Biblioteca de Anuncios, con todos mis filtros |
| `rutinas/rastrear-diario.md` | El prompt de la rutina que corre todas las mañanas y te trae 15 ofertas |
| `skills/modelar/SKILL.md` | La skill para llevar una oferta ganadora a otro mercado (oferta, landing, tienda, anuncios) |
| `sops/cbo-madre.md` | Cómo testeo, renuevo creativos y escalo en Meta Ads |

## Configuración paso a paso (30-45 minutos)

### 1 · Instalá Claude Code

- Necesitás una suscripción de Claude (Pro o Max).
- Instalá Claude Code desde **claude.com/claude-code**, o usá la app de escritorio de Claude (pestaña Code).
- Verificá que Claude tenga **navegador habilitado**: la skill `/cazar` navega la Biblioteca de Anuncios.

### 2 · Creá tu carpeta de proyecto (tu segundo cerebro)

1. Creá una carpeta, por ejemplo `Mi Negocio` en el escritorio.
2. Adentro, creá las carpetas `RAW`, `WIKI`, `OUTPUTS` y `scouting`.
3. Copiá `CLAUDE.md` de este kit a la raíz de la carpeta y **completá la sección "Mi negocio"** (qué vendés, mercados, precio, plataformas).
4. Abrí Claude Code en esa carpeta.

### 3 · Instalá las skills

Las skills son carpetas con un archivo `SKILL.md` adentro. Claude las carga solo cuando hacen falta.

- **Mac / Linux:** copiá las carpetas `skills/cazar` y `skills/modelar` a `~/.claude/skills/`.
- **Windows:** a `C:\Users\<tu-usuario>\.claude\skills\`.
- O más fácil: abrí Claude Code, arrastrá la carpeta `skills` del kit y pedile: *"Instalá estas skills en mi carpeta de skills de Claude Code."*

Reiniciá Claude Code. Para probar, escribí `/cazar crochet en Italia`.

### 4 · Programá la rutina diaria

1. Abrí `rutinas/rastrear-diario.md` y completá tus mercados y nichos donde dice `[PEGÁ ACÁ…]`.
2. En Claude Code pedile: *"Creá una tarea programada que corra todos los días a las 8:00 con este prompt"* y pegale el bloque de código del archivo.
3. Al día siguiente vas a tener tu primera lista en `scouting/`.

### 5 · Entrenala con tus Sí / No

Cada mañana marcá **Sí** o **No** en cada oferta, y si es No, por qué ("es marca personal", "ya lo probé", "nicho que no me gusta"). En una semana la lista empieza a traerte lo que realmente te interesa.

### 6 · Cuando una oferta te guste: `/modelar`

Escribí `/modelar`. Te va a preguntar el mercado y los dos links (arsenal + landing). Después arma la oferta, la landing y la tienda, **para y te pide aprobación**, arma los 10 anuncios, **vuelve a parar**, y recién ahí lanzás.

### 7 · Lanzá con la CBO madre

Seguí `sops/cbo-madre.md` al pie de la letra: 1 campaña CBO, 1 conjunto, 9-10 anuncios, 3 veces el ticket, a las 00:30 del día siguiente.

## Lo más importante

**Corregí a Claude y pedile que lo guarde.** Al principio se va a equivocar bastante. Cada corrección que queda en `memoria.md` hace que la próxima vez salga mejor. Ese es el verdadero sistema: no el prompt del primer día, sino las 50 correcciones que le das en el primer mes.

¿Dudas? Escribime por Instagram.
