# SOP · CBO madre — testear, renovar y escalar en Meta Ads

Una sola campaña por oferta y por cuenta publicitaria. La misma campaña hace el test, la renovación de creativos y la escala.

**Por qué funciona:** cada creativo nuevo entra a un activo que ya tiene historial de conversiones (no arranca de cero), el presupuesto no queda repartido en campañas que compiten entre sí, y el aprendizaje del algoritmo solo crece.

## 1 · Lanzamiento

| Parámetro | Valor |
|---|---|
| Campañas por oferta y cuenta | **1** (nunca dos para la misma oferta) |
| Tipo | CBO (presupuesto a nivel campaña) |
| Objetivo | Ventas, optimizado a Compra |
| Estructura | **1-1-9**: 1 campaña · 1 conjunto · 9-10 anuncios |
| Público | Target al país del mercado. Amplio: solo edad y sexo, sin intereses |
| Presupuesto diario | **3 veces el ticket del producto**, redondeado a múltiplo de 5 (vendés a USD 15 → USD 45/día) |
| Inicio | Programada para las **00:30 del día siguiente** (nunca "ahora": arranca con el día a medias) |

## 2 · Test

- Dejala aprender **1,5-2 días** sin tocar nada.
- Si ya gastó **~2 tickets** sin clics, sin carritos y sin checkouts → apagala. Es la oferta la que no funciona, no el creativo.
- Si hay ventas, dejala seguir: el cuadro del día 3 suele ser distinto al del día 1.

## 3 · Renovación de creativos

- Cada tanda nueva de anuncios entra como **un conjunto nuevo dentro de la misma CBO madre**. Nunca una campaña nueva.
- **No apagues los conjuntos viejos.**
- Los anuncios malos simplemente no reciben presupuesto. Los ganadores se lo llevan solos. Así validás creativos gastando muchísimo menos.
- **No apagues los anuncios que gastan pero no venden.** Muchas veces son los que educan al comprador, y la venta la cierra otro anuncio. Son parte del embudo.
- Cada tanda tiene que traer **conceptos realmente distintos**, no variaciones mínimas del mismo.

## 4 · Escala vertical

- Si la campaña se sostiene con buen ROAS, **duplicás el presupuesto**: 45 → 90 → 180 → 400 → 800 → 1.600 USD/día.
- Hasta **2 escalas por día**, mientras el ROAS aguante.
- Nunca vuelvas el presupuesto al punto de partida: tirás el momentum.
- Si en un nivel deja de sostener, bajá un escalón y estabilizá. Prefiero varias campañas estables con presupuesto medio antes que una sola al límite.

## 5 · Cost cap con tus ganadores

Cuando tengas **3 anuncios ganadores**:
1. Calculá su CPA promedio (ej. USD 10).
2. Nueva campaña con cost cap: **6 conjuntos**, cada uno con un costo por resultado escalonado (10, 11, 12, 13, 14, 15…) y **USD 30 por conjunto**, con los 3 ganadores adentro.
3. **Día 2:** apagá los conjuntos que no gastaron o no vendieron.
4. Los que funcionan los vas duplicando a diario (30 → 60 → 120 → 240…). Si un día no gastan, al siguiente los reiniciás en 30.

## 6 · Checklist antes de publicar

- [ ] Parámetros UTM en todos los anuncios (para que tu herramienta de tracking atribuya cada venta).
- [ ] Mejoras automáticas de Advantage+ creativo **desactivadas**.
- [ ] Target en el **país correcto** (un clásico: pautar en Argentina algo que era para Italia).
- [ ] Multianunciante (anuncios de otras marcas mezclados con el tuyo) desactivado en el conjunto.
- [ ] Inicio programado a las 00:30 del día siguiente.
- [ ] Plan de renovación de creativos y de escala listo.
