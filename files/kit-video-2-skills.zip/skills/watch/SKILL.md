---
name: watch
description: Analiza un video o anuncio de la competencia desde una URL (YouTube, TikTok, Instagram, Biblioteca de Anuncios de Meta, X) y devuelve un .md con la transcripción limpia, hooks, estructura, dolores, prueba social, B-rolls, CTA y dos prompts listos para replicarlo en otro idioma. Usar con "mirá este video", "modelá este anuncio", "sacale el guion a", "replicá este creativo" o cualquier URL de video.
---

# /watch — Sacarle el ADN a un anuncio ganador

**Solo analiza, no produce video.** Devuelve un `.md` que después alimenta la producción (skill `/anuncios-ia`).

## Preflight

1. Tener `yt-dlp` instalado (`brew install yt-dlp` o `pip install yt-dlp`).
2. Si la URL es de la Biblioteca de Anuncios, usar `https://www.facebook.com/ads/library/?id=<id>`: yt-dlp la descarga.
3. Preguntar una sola vez, si no se sabe por el contexto:
   - **Idioma y acento destino** (español neutro, rioplatense, inglés US, italiano, portugués BR…).
   - **Producto o nicho** al que se va a adaptar.

## Fase 1 · Descargar metadata y subtítulos

```bash
mkdir -p /tmp/watch-<slug> && cd /tmp/watch-<slug>
yt-dlp --skip-download --write-info-json --write-auto-subs --write-subs \
  --sub-langs "es,es-419,en,pt,it,fr,de,orig" --sub-format "vtt/srt/best" \
  -o "%(id)s.%(ext)s" "<URL>"
```

Si YouTube devuelve error 429, esperar 30 s y reintentar con menos idiomas.

## Fase 2 · Transcribir (si no hay subtítulos)

```bash
yt-dlp -x --audio-format mp3 -o "%(id)s.%(ext)s" "<URL>"
whisper <id>.mp3 --model small --word_timestamps True --output_format vtt
```

Whisper local es gratis (`pip install openai-whisper`). Alternativa paga: la transcripción de ElevenLabs.

## Fase 3 · Limpiar la transcripción

Sacar encabezados, timestamps y etiquetas del `.vtt`, deduplicar líneas consecutivas y dejar el texto plano en `transcript_full.txt`.

## Fase 4 · Análisis estructural

1. **Metadata:** título, autor, fecha, duración, vistas, URL.
2. **Hooks** (primeros 3-5 segundos): tipo (pregunta, cifra, reto, secreto, promesa, dolor), nivel de conciencia al que le habla y puntaje 1-10.
3. **Estructura en movimientos** (3-7): hook → dolor → mecanismo → prueba → oferta → CTA, con minuto:segundo y el tono de cada uno.
4. **Dolores** que martilla (3-8), explícitos.
5. **Prueba social y garantía:** cifras, cantidad de clientes, testimonios, autoridad del narrador.
6. **Inventario de B-rolls:** qué escenas se ven (manos trabajando, producto, celular con notificaciones, antes/después…). Sirve para generarlas después.
7. **CTA:** texto literal, en qué segundo aparece y tipo (descuento, urgencia, bonus).
8. **Popups y textos en pantalla:** qué dicen y cuándo aparecen (hay que recrearlos traducidos).
9. **Voz:** género y tono del locutor (mirá o escuchá el video, no lo asumas por el tema).

## Fase 5 · Dos prompts listos para pegar

**5.a · Guion adaptado**, en el idioma destino:
- Mismo ángulo y estructura, con referencias culturales adaptadas (no traducción literal).
- **Sin precios en moneda concreta** si el anuncio se va a usar en varios países: usar porcentajes ("50% OFF") o "mirá el precio abajo". Excepción: campañas a un solo país anglo, donde funcionan cifras concretas de ganancia ("$2,000/mo").
- Trato correcto (tú / vos / usted) según el mercado.
- Sin guiones largos (—) sueltos: usar coma o punto (rompen la sincronización de subtítulos).

**5.b · Prompt técnico de producción:** formato (réplica, UGC, B-roll con voz, talking head), duración, género de voz, B-rolls a generar y CTA.

## Fase 6 · Salida

Guardar en `OUTPUTS/AAAA-MM-DD-watch-<slug>.md` con todas las secciones y los dos prompts.

## Reglas

1. Nunca inventar contenido del video: si la transcripción no lo dice, no está.
2. Fechas absolutas.
3. Marcar suposiciones: (suposición, no confirmado).
4. Un solo idioma en los prompts de replicación.
5. No producir el anuncio: eso lo hace `/anuncios-ia`.
