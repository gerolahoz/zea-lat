---
name: anuncios-ia
description: Produce anuncios en video para Meta Ads con IA a partir de anuncios ganadores de la Biblioteca de Anuncios: réplicas traducidas, UGC con avatar, B-rolls con voz en off, split y estáticos. Incluye limpieza del video original, voz, subtítulos karaoke, música, efectos y una página de previsualización. Usar con "hacé los anuncios", "replicá estos anuncios", "hacé un UGC", "hacé los 3 anuncios más vistos de esta página".
---

# /anuncios-ia — La fábrica de anuncios con IA

Input típico: *"Hacé los 3 anuncios más vistos de esta página de la Biblioteca de Anuncios: uno como réplica, uno como UGC con IA y uno como B-roll con IA. Mercado: [X], acento: [Y], oferta: [link de la landing]."*

## Stack

| Herramienta | Para qué | Variable |
|---|---|---|
| Claude Code | Centro de comando: orquesta todo | — |
| kie.ai | Video (Veo, Kling), imágenes (GPT Image), lipsync | `KIE_API_KEY` |
| Google AI Studio (Gemini) | Voces TTS baratas + análisis de video (detecta textos y popups con su timing) | `GEMINI_API_KEY` |
| ElevenLabs | Voces premium (opcional, más caro) | `ELEVENLABS_API_KEY` |
| Vmake | Borra subtítulos, textos, popups y marcas de agua del video original | `VMAKE_API_KEY` |
| HyperFrames | Edición: une clips, voz, subtítulos, popups, música y motion graphics | — |
| openai-whisper | Transcripción con tiempos por palabra (karaoke) | — |
| ffmpeg + yt-dlp | Cortes, mezcla de audio, descargas | — |

Todas las claves van en `.env`, nunca en el código.

## Paso 1 · Input y análisis

1. Del link de la Biblioteca de Anuncios, listar el arsenal y quedarse con los **más vistos o más duplicados** (ordenar por impresiones).
2. Descargar cada video (`yt-dlp`).
3. Correr `/watch` sobre cada uno: guion, estructura, hooks, dolores, CTA, B-rolls, popups y **género de la voz**.
4. Confirmar mercado, idioma y acento (no asumir).

## Paso 2 · Los formatos

| Formato | Qué es | Cuándo |
|---|---|---|
| **Réplica** | El mismo video original, limpio de textos, con voz, subtítulos y popups nuevos en tu idioma | Cuando el video ya ganó en su mercado: es lo más seguro |
| **UGC con IA** | Un avatar hablando a cámara tipo selfie + B-rolls | Testimonios, "cómo me cambió…" |
| **B-roll con IA** | Clips generados + voz en off + subtítulos | Mostrar proceso o resultado |
| **Split** | Mitad avatar, mitad B-roll | Variante del UGC |
| **Imagen estática** | Imagen con texto (image-to-image sobre una referencia) | La variante más barata |

Con un guion ganador, producir varios formatos da variantes para testear sin escribir guiones nuevos.

## Paso 3 · Pipeline de RÉPLICA (paso a paso)

1. **Detectar** con Gemini (análisis de video) todos los textos: subtítulos, popups, cartel final, marca de agua, con su tiempo y estilo. Sirve para **saber qué dice y cuándo**, para traducirlo.
2. **Limpiar** el video con Vmake (`videoscreenclear`): devuelve el video sin subtítulos, popups ni marcas. Nada de tapar con cajas negras ni difuminar.
3. **Revisar frames** del original cada ~2 s: Vmake también borra los **popups decorativos** (frases gancho en cajas de color). Hay que catalogarlos (texto, colores, forma, orden) y recrearlos traducidos. Si no, el anuncio pierde ese refuerzo visual.
4. **Traducir el guion** adaptado (Paso 5.a de `/watch`).
5. **Voz:** mismo género que el locutor original (mirá el video, no lo asumas por el tema).
   - Generarla a velocidad natural y medir la duración.
   - Si queda **más larga** que el video → acelerar la voz (hasta +30/40% suena natural).
   - Si queda **más corta** → **acelerar el video** (`setpts`), **nunca desacelerar la voz**: suena a cámara lenta.
6. **Subtítulos karaoke** (ver reglas abajo).
7. **Popups traducidos** en el mismo tiempo que el original, sincronizados con la **voz nueva** (no con el tiempo viejo).
8. **Música de fondo** a -22 dB y **efectos:** un swell al inicio y un impacto en el CTA (~3 s antes del final).
9. **Exportar en 9:16** (1080×1920 o 720×1280). Siempre con la relación de aspecto explícita.

## Paso 4 · Pipeline de UGC con IA

Estructura en dos bloques:

- **Bloque A, el avatar hablando:** generado con un modelo de video que acepte diálogo (Veo, Kling…), con **su audio nativo**. En el prompt va el texto exacto que dice + el acento ("Argentinian Spanish, Buenos Aires accent"). **Nunca poner una voz TTS encima del avatar:** rompe el lipsync y se nota falso.
- **Bloque B, los B-rolls:** acá sí va la voz TTS (Gemini o ElevenLabs) con el resto del guion.

**Ahorro:** el video con avatar se cobra por cada 8 segundos. Generalo **solo para los segundos en que se ve la cara** (típicamente el hook). El resto va sobre B-roll con voz TTS: gastás un 50-70% menos.

El karaoke del bloque A se saca transcribiendo el **audio real del avatar** (puede cambiar palabras respecto del guion).

## Paso 5 · Pipeline de B-ROLL con IA

1. Del inventario de B-rolls de `/watch`, escribir 8-10 prompts de clips cortos (mismo sujeto, luz y estilo en todos).
2. Generarlos en el **modelo más barato** que cumpla (720p, 4-8 s). Clips de 8 s: recortar 0,2 s al inicio y al final para sacar microglitches.
3. Voz en off (TTS) + karaoke + música + CTA final ("Tocá el botón de abajo").

## Reglas de subtítulos (karaoke)

- Tiempos **por palabra** con `openai-whisper` (`word_timestamps=True`) sobre el **audio final**, alineados con el guion con `difflib`. Nunca repartir el texto proporcionalmente: se desincroniza.
- **Máximo 4-5 palabras por línea.** En 720×1280, tamaño ~52 px con márgenes laterales de 54 px o más. A 38-40 px es ilegible en un celular sin sonido.
- Salto de línea automático activado (en ASS: `WrapStyle: 0`).
- Cada línea queda en pantalla **hasta que arranca la siguiente** (si no, parpadea en cada pausa).
- **Nada de signos sueltos** en el guion (" — ", " … "): generan subtítulos duplicados. Usar coma o punto.
- Posición: abajo sobre B-roll. Si el frame es una **"quote card"** (texto sobre fondo liso), centrado.
- Palabra que se está diciendo resaltada en color.

## Reglas de guion

- **Sin precios en moneda concreta** si el anuncio corre en varios países (usar "50% OFF" o "mirá el precio abajo").
- En anuncios para EE. UU. o anglo: cifras concretas de ganancia funcionan mejor ("$2,000/mo"). Inversión inicial chica y concreta ("just $20 in supplies").
- Trato según mercado (tú / vos / usted), sin mezclar.
- **Iteraciones sobre un ganador:** mantener el mismo ángulo y mensaje, y cambiar solo detalles (wording del hook, props, luz, encuadre). Si cambiás el ángulo, ya no es una iteración.

## Paso 6 · Revisión

1. Revisar frames de cada video (uno cada 1-2 s en el primero de la tanda): subtítulos cortados, popups faltantes, textos del original que quedaron.
2. Re-transcribir el audio final con whisper para confirmar que la voz no se cortó (los TTS a veces truncan textos largos: dividir en frases de menos de 25 palabras).
3. Armar **una página HTML** con todos los videos en grilla (`<video>` por tarjeta, agrupados por tanda) para revisarlos juntos. Nunca entregar una lista de links.

## Paso 7 · Subida

Nombres de archivo claros (`ad-01_9x16.mp4`). Subir al Administrador de Anuncios o con una herramienta de carga masiva, dentro de la estructura **CBO madre** (ver el kit del video 1).

## Reglas de costo

- Siempre el modelo y la resolución **más baratos** que cumplan (720p, 1K en imágenes, duración mínima útil).
- Escalar al modelo caro **solo si el barato falló dos veces seguidas**.
- Probar primero con 1 anuncio antes de tirar una tanda entera.
- Avisar antes de cualquier tanda de más de USD 5.
- Reciclar clips que ya tengas antes de generar nuevos.

## Lo más importante

Cada corrección que le hagas ("los subtítulos están muy chicos", "la voz tiene que ser de hombre", "faltan los popups") pedile que la **guarde en memoria.md**. Así, en dos semanas, la fábrica te sale como la querés sin repetir errores.
