# Kit video 2 · Tu fábrica de anuncios con IA en Claude Code

Este kit es el sistema que muestro en el video: le paso a Claude un link de la Biblioteca de Anuncios y me devuelve réplicas, UGC y B-rolls con IA, listos para subir. Incluye:

| Archivo | Qué es |
|---|---|
| `CLAUDE.md` | Las instrucciones de tu "segundo cerebro" (cómo trabaja Claude y cómo aprende de tus correcciones) |
| `.env.example` | La plantilla para tus claves de API |
| `skills/watch/SKILL.md` | Analiza un anuncio ganador: guion, hooks, dolores, CTA, B-rolls y prompts para replicarlo |
| `skills/anuncios-ia/SKILL.md` | Produce los anuncios: réplica, UGC, B-roll, con subtítulos, música y previsualización |

## Configuración paso a paso (1 hora)

### 1 · Instalá Claude Code

Suscripción de Claude (Pro o Max) + Claude Code desde **claude.com/claude-code** (o la app de escritorio, pestaña Code).

### 2 · Sacá tus claves de API

| Servicio | Para qué | Dónde |
|---|---|---|
| **kie.ai** | Video e imágenes con IA (Veo, Kling, GPT Image) | kie.ai → API Keys. Cargás créditos |
| **Google AI Studio** | Voces baratas y análisis de video | aistudio.google.com → Get API key. Tiene uso gratis diario |
| **ElevenLabs** (opcional) | Voces premium | elevenlabs.io → API Keys |
| **Vmake** (solo réplicas) | Borrar textos y subtítulos del video original | vmake.ai → Developers |

No las necesitás todas para arrancar: con **kie.ai + Google AI Studio** ya podés hacer UGC y B-rolls. Vmake solo si vas a hacer réplicas.

### 3 · Armá la carpeta del proyecto

1. Creá una carpeta (ej. `Fabrica de Anuncios`) y copiá adentro `CLAUDE.md`.
2. Copiá `.env.example`, renombralo a `.env` y pegá tus claves.
3. Instalá las skills: copiá las carpetas `skills/watch` y `skills/anuncios-ia` a `~/.claude/skills/` (Windows: `C:\Users\<tu-usuario>\.claude\skills\`), o arrastralas a Claude Code y pedile que las instale.

### 4 · Pegá el prompt de configuración

Abrí Claude Code en la carpeta y pegá esto:

```
Quiero armar una fábrica de anuncios en video con IA en esta carpeta.
1. Instalá lo que haga falta: ffmpeg (con soporte de subtítulos libass), yt-dlp, openai-whisper (Python) y HyperFrames (https://hyperframes.heygen.com).
2. Leé mis claves del archivo .env (nunca las copies al código ni a páginas públicas).
3. Probá cada clave con una prueba mínima y barata: una imagen 1K en kie.ai, una frase de voz en Gemini, y (si están) una frase en ElevenLabs y una tarea chica en Vmake. Decime cuáles funcionan.
4. Creá memoria.md y guardá ahí cada corrección que te haga de ahora en adelante.
5. Creá las carpetas OUTPUTS/ y work/ para los videos.
```

### 5 · Tu primera tanda

```
Hacé los 3 anuncios más vistos de esta página de la Biblioteca de Anuncios: [LINK DEL ARSENAL]
Uno como réplica, uno como UGC con IA y uno como B-roll con IA.
Mercado: [LATAM español neutro / Argentina / EE. UU. / Italia…] · Acento: [rioplatense / neutro…]
Mi oferta: [NOMBRE + LINK DE TU LANDING].
Videos 9:16, subtítulos karaoke grandes, música de fondo baja.
Al final, armame una página HTML con los 3 videos para revisarlos.
```

Antes de gastar en generación, Claude te muestra el análisis y los guiones.

### 6 · Corregí y hacelo guardar

Mirá los videos y decile todo lo que no te guste: *"los subtítulos más grandes"*, *"la voz tiene que ser de hombre"*, *"faltan los popups del original"*, *"la música está muy fuerte"*. Terminá siempre con **"guardalo en memoria"**. Así cada tanda sale mejor que la anterior.

### 7 · Subí los anuncios

Subilos a tu CBO madre como un **conjunto nuevo** (ver el kit del video 1). Nunca una campaña nueva por cada tanda.

## Costos de referencia

- Imagen estática: centavos.
- B-roll con voz: poco (clips cortos + voz barata).
- UGC con avatar: lo más caro. Por eso el avatar se genera solo para los segundos en que se ve la cara.
- Réplica: Vmake + voz. Suele ser de lo más barato y de lo que mejor funciona, porque el video ya ganó en su mercado.

Pedile siempre a Claude que use el modelo más barato que cumpla y que te avise antes de tandas grandes.

¿Dudas? Escribime por Instagram.
