# Mi segundo cerebro — instrucciones para Claude

Sos el encargado de este proyecto. Leé este archivo al empezar cualquier sesión y respetalo aunque no te lo repita.

## Estructura de carpetas

```
RAW/        Material crudo que yo agrego (notas, transcripciones, capturas). Solo lectura para vos.
WIKI/       Conocimiento destilado, un archivo por tema. Lo mantenés vos.
OUTPUTS/    Entregables importantes con fecha (AAAA-MM-DD-nombre.md). Los escribís vos.
scouting/   Listas diarias de ofertas + criterio aprendido.
memoria.md  Reglas y correcciones que te doy. Lo más importante del proyecto.
```

## Cómo trabajás

1. **Antes de responder algo sustancial, buscá primero en WIKI/ y en memoria.md.** No respondas de memoria genérica lo que este proyecto ya sabe.
2. **Cada vez que te corrijo algo, lo guardás en memoria.md** como una regla corta: qué hacer, por qué, y cómo aplicarlo. Antes de cada tarea, releé las reglas que apliquen.
3. **Guardá los entregables en OUTPUTS/** con fecha y agregalos a OUTPUTS/index.md.
4. **Cuando agrego material en RAW/**, leelo entero, extraé datos, decisiones y cifras, y actualizá los temas de WIKI/.
5. **No borres información:** si algo queda viejo, movelo a una sección "Historial" con la fecha.

## Reglas generales

- Fechas siempre absolutas (2026-09-24, nunca "ayer").
- Si algo es una suposición tuya, marcalo: (suposición, no confirmado).
- Nunca inventes datos, cifras ni testimonios.
- Nunca pongas claves de API en el código ni en páginas públicas: van en un archivo .env.
- Antes de cualquier gasto (generación de imágenes, video, voz) de más de USD 5, avisame.
- Usá siempre la opción más barata que cumpla el objetivo (menor resolución útil, menor duración, modelo más barato).

## Mi negocio (completá esto)

- Qué vendo: [productos digitales / nicho]
- Mercados: [países]
- Precio de referencia: [ticket]
- Plataforma de tienda: [Impultienda / Hotmart / Shopify]
- Tracking: [Utmify / otro]
