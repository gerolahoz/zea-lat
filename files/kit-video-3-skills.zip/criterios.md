# Criterios para encontrar una oferta winner

**La regla #1: no inventar productos.** Si alguien paga anuncios durante semanas, es porque vende. Buscá lo que ya funciona, modelalo, mejoralo y llevalo a otro mercado.

## 1 · Para que pase (tiene que cumplir todo)
- **15 o más anuncios activos** de la misma oferta.
- **El anuncio más viejo con 3 días o más** (lo que arrancó hoy es alguien testeando).
- **Al menos 1 anuncio en video** (los videos son más replicables y escalables).
- **Producto digital replicable, pero no por todos:** una guía, un pack, una app o un chat con IA sí; un curso de meses, no.

## 2 · Descartar si… (con uno solo, afuera)
- **Marca personal:** vende por la cara o la autoridad de una persona.
- **Varios productos:** es un catálogo, no una oferta atacada desde muchos ángulos.
- **Manda a WhatsApp:** no hay un checkout para modelar.
- **Regala algo gratis:** "0 dólares" y después upsells escondidos.
- **Tienda o editorial:** muchos productos, operación de tienda.

## 3 · Puntaje de 0 a 4 (1 punto por señal)
- **Antigüedad:** el anuncio más viejo lleva 45 días o más.
- **Volumen:** 50 o más anuncios del mismo anunciante.
- **Duplicación:** el mismo anuncio repetido 10 o más veces (ese es el ángulo a copiar).
- **Hueco:** en otro país hay 0-1 vendedores fuertes.

4/4 → copiala · 3/4 → candidata · 2 o menos → observar.

## 4 · ¿Hay lugar?
- 2-6 vendedores sin que ninguno domine → **entrar**.
- 7 o más con anuncios parecidos → **buscar un subnicho**.
- 0-1 o anuncios que mueren rápido → **descartar**.
- Un gigante domina → **copiarlo en otro país**.

## 5 · A qué país llevarla
Mercado A (donde ya está saturado) → Mercado B (donde todavía no hay nadie). Brasil suele ser la cuna de muchas modas. Prioridad de destino: 1) inglés, 2) Europa, 3) LATAM, 4) Brasil. **Que tenga sentido:** cómo hacer mate no se vende en EE. UU.; cómo cocinar galletitas sirve en cualquier país.

Al llevarla: mejores bonos, mejor producto y dolores más específicos.
