# Prompts para entrenar a /cazar

## Feedback del scouting del día
```
Te dejo mi veredicto del scouting de hoy (scouting/AAAA-MM-DD.md):
1 Sí: oferta simple, un solo producto, 3 meses corriendo. La voy a modelar para Italia.
2 No: es marca personal, todos los anuncios son la misma coach.
3 No: vende 6 productos distintos, es un catálogo.
4 Sí: interesante, pero tiene poca antigüedad; dejala en observación.
5 No: manda a WhatsApp.
Marcá [x] / [N] en el archivo y actualizá scouting/criterio-aprendido.md.
```

## Pasarle una oferta que encontraste vos
```
Encontré esta oferta que me sirve: [LINK DEL ARSENAL EN LA BIBLIOTECA DE ANUNCIOS]
Analizala con los criterios de /cazar: cuántos anuncios activos tiene, antigüedad, videos,
landing real, qué ángulo está validado y en qué otros mercados corre.
Decime por qué me puede servir y agregalo a tu aprendizaje (scouting/criterio-aprendido.md)
para que la próxima vez me traigas ofertas parecidas.
```

## Cuando un día no trae nada
```
Hoy no me trajiste ninguna oferta testeable: [motivo, ej. todas eran catálogos o marca personal].
Revisá qué filtro dejó pasar eso, ajustalo en scouting/criterio-aprendido.md y corré /cazar de nuevo
sumando estos mercados o palabras clave: [...]
```
