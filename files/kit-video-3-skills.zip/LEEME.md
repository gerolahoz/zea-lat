# Kit · Cómo encuentro productos ganadores (con Claude buscando por mí)

Este kit es todo lo que muestro en el video: los criterios que uso para saber si una oferta vale la pena, la skill que busca ofertas ganadoras en la Biblioteca de Anuncios y la rutina que lo hace sola todas las mañanas.

| Archivo | Qué es |
|---|---|
| `criterios.md` | La hoja de criterios: qué tiene que cumplir, qué descartar, el puntaje de 0 a 4 y a qué país llevarla |
| `skills/cazar/SKILL.md` | La skill `/cazar` completa, con todos mis filtros y umbrales |
| `rutinas/rastrear-diario.md` | El prompt de la rutina diaria de las 8:00 que te deja 15 ofertas |
| `prompts/feedback.md` | Cómo darle feedback (Sí / No + por qué) y cómo pasarle ofertas que encontrás vos |
| `diagramas/` | Los dos diagramas del video |
| `CLAUDE.md` | La plantilla de tu "segundo cerebro" (donde Claude guarda lo que aprende) |

## Configuración paso a paso (20-30 minutos)

### 1 · Instalá Claude Code
Necesitás una suscripción de Claude (Pro o Max). Instalá Claude Code desde **claude.com/claude-code** o usá la app de escritorio (pestaña Code). Tiene que tener el **navegador habilitado**: `/cazar` recorre la Biblioteca de Anuncios.

### 2 · Armá tu carpeta
1. Creá una carpeta (ej. `Mi Negocio`) con las subcarpetas `scouting`, `WIKI`, `OUTPUTS`.
2. Copiá `CLAUDE.md` a la raíz y completá la sección "Mi negocio".
3. Creá `scouting/ofertas-probadas.md` (vacío por ahora): ahí vas anotando lo que ya testeaste.

### 3 · Instalá la skill
Copiá la carpeta `skills/cazar` a `~/.claude/skills/` (Windows: `C:\Users\<tu-usuario>\.claude\skills\`), o arrastrala a Claude Code y pedile *"instalá esta skill"*. Reiniciá y probá: `/cazar jardinería en Italia`.

### 4 · Programá la rutina de las 8:00
Abrí `rutinas/rastrear-diario.md`, completá tus mercados y nichos, y pedile a Claude: *"Creá una tarea programada todos los días a las 8:00 con este prompt"*. Corre sola ~30-40 minutos y te deja `scouting/AAAA-MM-DD.md` con 15 ofertas ordenadas.

### 5 · Entrenala todos los días
Esto es lo que hace que funcione. Marcá **Sí o No en cada oferta, con el porqué** (usá los prompts de `prompts/feedback.md`). Los primeros días la lista va a traer cosas que no sirven: es normal. A la semana ya trae lo que buscás.

## Lo más importante
**La IA no hace por vos lo que vos no sabés hacer.** Leé `criterios.md` y entendelo antes de delegar: así sabés qué está haciendo Claude y lo podés corregir.

¿Dudas? Escribime por Instagram: @gerolahoz
