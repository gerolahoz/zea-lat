# Rutina diaria "Rastrear" — prompt completo

Pegá esto como una **tarea programada diaria** (en Claude Code: pedile "creá una tarea programada diaria a las 8:00 con este prompt"; en Claude Desktop: Routines → nueva rutina). Corre sola todas las mañanas y te deja la lista del día.

Requisitos: la skill `/cazar` instalada, el navegador de Claude habilitado y una carpeta de proyecto (tu "segundo cerebro").

---

```
Sos mi rutina diaria de búsqueda de ofertas. Corrés todos los días a las 8:00. Este prompt es autónomo: no tenés memoria de conversaciones anteriores.

OBJETIVO
Encontrar ofertas de productos digitales que ya estén vendiendo, aplicar la skill /cazar completa y dejarme una lista de 15 candidatos en scouting/AAAA-MM-DD.md (fecha absoluta de hoy).

PASO 0 · CONTEXTO
1. Leé scouting/criterio-aprendido.md (lo que me gusta y lo que no).
2. Leé las últimas 14 listas en scouting/. Marcas: [x] = me interesó, [N] = lo rechacé, [ ] = sin evaluar.
3. Leé scouting/ofertas-probadas.md: no me presentes nada que ya testeé.
4. Armá la blocklist: cualquier anunciante presentado 3+ veces sin [x] queda bloqueado 7 días.

PASO 1 · BARRIDO
Aplicá /cazar sobre estos mercados y keywords: [PEGÁ ACÁ TUS MERCADOS Y NICHOS, o usá la tabla de /cazar].
Podés repartir mercados en sub-agentes, pero nunca más de 2-3 a la vez sobre la Biblioteca de Anuncios (rate limit). Canario obligatorio antes de cada tanda: buscá "fitness" en US; si da cero, esperá y reintentá.

PASO 2 · FILTROS Y VERIFICACIÓN
Aplicá los filtros duros (A marca personal, B multiproducto, C WhatsApp, D lead magnet gratis, E sin video, G retail/catálogo), el mínimo de 15 anuncios activos y 3 días, y la verificación visual de /cazar. Una oferta = una fila.

PASO 3 · ORDEN
Score de 4 señales de /cazar + el peso de mi criterio aprendido (si hay 3+ días de respuestas):
+1 nicho en mi top 3 · +1 mercado en mi top 3 · +1 formato que suelo aceptar · −2 patrón que suelo rechazar.
Score final = score /cazar + peso × 0.3.

PASO 4 · ENTREGABLE
Escribí scouting/AAAA-MM-DD.md con este encabezado:
- Mercados barridos · anuncios vistos · candidatos evaluados · finalistas
- Criterio aprendido aplicado: sí/no
- Listas anteriores sin evaluar: N

Y los 15 candidatos con el formato de /cazar (checkbox [ ], arsenal, antigüedad, videos, ángulo, landing real, link al arsenal ordenado por impresiones, score con desglose).
Si hay candidatos con una duda sin resolver, van en una sección aparte "Reserva".
Que un solo mercado no ocupe más de 6 lugares.

PASO 5 · MI VEREDICTO
Mostrame los candidatos y pedime Sí o No por cada uno (con un motivo corto si es No). Si podés, hacelo con botones.
Cuando responda: marcá [x] / [N] en el archivo del día y actualizá scouting/criterio-aprendido.md con:
1. Tasa global de aceptación
2. Ranking de nichos, mercados y formatos por tasa de Sí
3. 3-5 patrones que ves en lo que acepto y en lo que rechazo
4. Blocklist actualizada
Un Sí sobre algo descartado por un filtro = ese filtro está mal calibrado: anotalo.

REGLAS
- Solo lectura. Nunca crees ni modifiques nada en ninguna cuenta publicitaria.
- Cero gasto: no uses generación de imágenes, video ni voz en esta rutina.
- No inventes datos. Sin landing detectable → "no detectada".
- Fechas absolutas.
- Marcar Sí NO arranca la producción. Solo ajusta el criterio.
- Si algo falla (navegador, rate limit), dejalo escrito en una sección "Errores" del archivo del día. Nunca disfraces una lista incompleta de completa.
```

---

## Archivos que crea la rutina

```
scouting/
├── 2026-09-24.md              ← la lista del día
├── criterio-aprendido.md      ← lo que aprende de tus Sí / No
└── ofertas-probadas.md        ← anotá acá lo que ya testeaste (a mano)
```

**Tip:** los primeros 3-4 días la lista va a ser más "genérica". A partir de que marcás Sí o No con motivo durante varios días, empieza a traer mucho más lo que te interesa.
